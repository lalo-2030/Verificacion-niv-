---
name: Technical Precision Utility
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#330001'
  on-tertiary: '#ffffff'
  tertiary-container: '#5a0004'
  on-tertiary-container: '#ff5248'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ab'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#93000b'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  vin-display:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0.15em
  vin-display-mobile:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: 0.12em
  data-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  data-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-md: 1rem
  margin: 1rem
  margin-md: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style
The design system embodies utilitarian minimalism engineered for field operations, automotive inspectors, and forensic verification. It operates as an instrument rather than an expressive canvas: deliberate, cold, hyper-legible, and uncompromisingly functional under harsh outdoor lighting and grease-smeared screen conditions.

### Aesthetic Paradigm
- **Industrial Utilitarianism:** Visual hierarchy built entirely on strict typographical scale, crisp hairline borders, and unambiguous surface contrasts.
- **Instrument-Grade Neutrality:** Chromatic stillness. The canvas relies on slate, charcoal, and pure white to eradicate cognitive fatigue during high-volume vehicle intake.
- **Binary Semantic Weight:** Color is withheld entirely from branding or decoration. Chromatic signals are reserved exclusively for machine verification states: Emerald Green for checksum clearance and Crimson Red for checksum failure or fraud indicators.

## Colors
The palette is engineered around high luminance contrast ratios (passing WCAG AAA for technical fields) and absolute semantic restraint.

### Surface and Canvas Architecture
- **Base Canvas (`#F1F5F9`):** A pale, anti-glare light slate background that reduces screen bounce and reflection in open-air lots.
- **Card Surface (`#FFFFFF`):** Pure white container surfaces creating an immediate, crisp foreground separation.
- **Primary Ink & Primary Surfaces (`#0F172A` / `#1E293B`):** Deep charcoal slates serving as the primary structural tone, actionable buttons, and high-emphasis labels.
- **Muted Neutral (`#64748B`):** Mid-tone slate for supporting metadata keys, field borders, and auxiliary structural rules.

### Semantic State Enforcement
- **Validation Pass (`#059669`):** Emerald Green used strictly for ISO 3779 checksum calculation passes, valid country/plant codes, and verified match badges.
- **Validation Error / Alert (`#DC2626`):** Crimson Red reserved for invalid check digits, illegal character entries (I, O, Q), assembly mismatch alerts, and corrupted records.
- **Inactive / Ghosted (`#CBD5E1`):** Subdued borders and disabled state fills.

## Typography
Typography is split purposefully between structural structural headings, high-density system prose, and fixed-width machine readouts:

1. **JetBrains Mono (Technical Core):** Applied without exception to raw 17-character VIN strings, WMI/VDS/VIS segment partitions, checksum calculations, engine codes, model years, and production sequence serials. Slashed zeroes and distinct character glyphs prevent misinterpretation of `8`/`B`, `0`/`D`, `5`/`S`, and `1`/`I`.
2. **Geist (Body & Metadata Labels):** A clinical, neutral neo-grotesque that handles metadata key-value pairings with high horizontal density and superior micro-legibility.
3. **Space Grotesk (Display & Section Headers):** Delivers an austere, industrial character to vehicle descriptors (e.g., Year, Make, Model, Body Style) without ornamental distraction.

## Layout & Spacing
The layout follows a strict, dense 4px baseline rhythm optimized for one-handed handheld devices and ruggedized industrial tablets.

### Grid & Density
- **Mobile Handheld (Compact):** Single-column stack with `margin: 1rem` and `gutter: 0.75rem`. Content cards maximize viewport real estate with zero extraneous horizontal buffer.
- **Tablet / Mounted Terminal:** 2-column or 3-column asymmetric layout. Column A anchors VIN input, optical scanner controls, and checksum indicator. Column B & C populate decoded taxonomy fields (Plant, Restraint, Engine, Transmission, Model Trim).
- **Component Padding:** Controlled by `space-sm` (8px) for tightly grouped attributes and `space-md` (12px) to `space-lg` (16px) for major card interiors, preserving data density without overcrowding touch targets.

## Elevation & Depth
This design system avoids soft ambient shadows, blurs, and skeuomorphic gradients in favor of **structural boundary elevation**.

- **Level 0 (App Canvas):** Muted background `#F1F5F9`.
- **Level 1 (Data Cards & Sheets):** Solid `#FFFFFF` background with a crisp `1px solid #CBD5E1` outline.
- **Level 2 (Active Focus & Scanned Modules):** Solid `#FFFFFF` background bound by a high-contrast `1.5px solid #0F172A` outline. No dropshadow.
- **Level 3 (Validation Overlays / Floating Command Bars):** Bounded by `1px solid #0F172A` with a razor-thin industrial contact shadow: `box-shadow: 0 4px 0 0 #0F172A`.

## Shapes
Geometry is disciplined, boxy, and architectural. The roundedness level is locked at `1` (Soft, 4px base radius).

- **Base Radius (`0.25rem` / `4px`):** Input fields, segmented buttons, badges, and internal data cells.
- **Container Radius (`0.5rem` / `8px`):** Root inspection cards, camera viewfinder bezels, and modal dialogs.
- **Pill Shapes:** Strictly prohibited. Badges, tags, and status chips remain rectangular with 4px corners to reinforce precision tool ergonomics.

## Components

### 1. VIN Input & Character Slot Matrix
- Standard inputs use a segmented 17-character fixed cell box (`JetBrains Mono`, all caps) or a monolithic text field with automatic uppercase transformation and spacing after characters 3 (WMI), 9 (Check Digit), and 11 (Plant).
- Banned characters (`I`, `O`, `Q` per ISO standard) trigger an immediate, inline crimson inline callout with invalid stroke feedback on the specific cell.

### 2. Checksum Status Banner
- **Valid:** 1px border of `#059669` over `#ECFDF5` fill with deep green monospace confirmation: `CHECKSUM: VALID [POSITION 9 = MATCH]`.
- **Invalid:** 1px border of `#DC2626` over `#FEF2F2` fill with deep red monospace warning: `CHECKSUM: FAIL [EXPECTED: '4', FOUND: 'X']`.

### 3. Data Cards
- Pure white background, `1px solid #E2E8F0`, `rounded-sm` (4px).
- Internal layout arranged as a two-column key-value matrix. Key labels (`Geist`, 11px uppercase bold, `#64748B`) stacked directly above values (`JetBrains Mono`, 14px, `#0F172A`).
- Sub-segment dividers use `1px solid #F1F5F9`.

### 4. Buttons & Field Triggers
- **Primary:** Background `#0F172A`, foreground `#FFFFFF`, no gradient, flat `4px` corner radius. Active state darkens to `#000000`.
- **Secondary / Offline Sync Trigger:** Background `#FFFFFF`, border `1px solid #0F172A`, text `#0F172A`.
- **Destructive / Reset:** Background `#FFFFFF`, border `1px solid #DC2626`, text `#DC2626`.
- Minimum touch target: 48px height for rapid field entry with gloves.

### 5. Data Chips & Attributes
- Rectangular blocks with `4px` border radius and `2px 8px` padding.
- Neutral Chip: Background `#F1F5F9`, border `1px solid #CBD5E1`, text `#334155`.
- Verified Chip: Background `#ECFDF5`, border `1px solid #059669`, text `#065F46`.
- Error Chip: Background `#FEF2F2`, border `1px solid #DC2626`, text `#991B1B`.

### 6. Barcode & OCR Viewfinder Reticle
- High-contrast charcoal viewfinder overlay (`#0F172A` with 60% opacity mask).
- Bounding reticle demarcated by 4 sharp right-angle corner brackets in `#FFFFFF` with an active laser guide line in `#059669` when lock-on occurs.