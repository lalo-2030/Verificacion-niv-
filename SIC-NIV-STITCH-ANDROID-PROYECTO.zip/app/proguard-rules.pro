# SIC-NIV: no custom ProGuard rules required.
