SIC-NIV – proyecto Android basado en el archivo Stitch proporcionado

QUÉ CONTIENE
- Proyecto Android listo para abrir en AndroidIDE/Android Studio.
- Interfaz offline inspirada en las especificaciones de diseño del archivo proporcionado.
- Verificador NIV/VIN de 17 caracteres.
- Rechazo de I, O y Q.
- Cálculo de dígito de control MOD-11 para la posición 9.
- Tabla detallada de valor, peso y producto.
- Resultado visual VALID / FAIL.
- Copiar/pegar, limpiar y bitácora local de verificaciones.
- No requiere conexión a Internet para funcionar.

IMPORTANTE
El archivo Stitch original contiene principalmente diseño/interacción de demostración. Esta versión convierte el botón “VERIFICAR MATEMÁTICAMENTE” en una comprobación funcional MOD-11 para que la APK tenga utilidad real. La pantalla de cámara/OCR del material original no se presenta como OCR funcional en esta versión porque el archivo suministrado no contiene un motor OCR/barcode offline.

CÓMO USARLO EN ANDROIDIDE
1. Descomprime este ZIP.
2. En AndroidIDE abre/importa la carpeta que contiene settings.gradle.
3. Abre el proyecto SIC-NIV-STITCH.
4. Ejecuta Sync/Build o Quick Run.
5. Genera el APK de debug.

SI APARECE “gradle: inaccessible or not found”
Eso indica un problema de configuración de Gradle/AndroidIDE, no de la pantalla del proyecto. En ese caso no borres el proyecto: envíame una captura y seguimos desde esa pantalla.

PAQUETE
com.sicniv.app
